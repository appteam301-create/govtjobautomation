<?php
use Illuminate\Support\Facades\Schedule;
Schedule::command('govjobs:crawl-due')->everyFiveMinutes()->withoutOverlapping();
