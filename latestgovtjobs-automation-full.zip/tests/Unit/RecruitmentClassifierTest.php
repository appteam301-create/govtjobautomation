<?php
namespace Tests\Unit;
use App\Models\GovernmentSource;
use App\Services\Extraction\RecruitmentClassifier;
use Mockery;
use PHPUnit\Framework\TestCase;
class RecruitmentClassifierTest extends TestCase { protected function tearDown():void{Mockery::close();parent::tearDown();} public function test_result_is_rejected():void{$s=Mockery::mock(GovernmentSource::class)->makePartial();$s->shouldReceive('rules')->andReturn(new class{function where(){return $this;}function first(){return null;}});$r=(new RecruitmentClassifier())->classify('Final Result for Recruitment','', $s);$this->assertFalse($r['is_recruitment']);} }
