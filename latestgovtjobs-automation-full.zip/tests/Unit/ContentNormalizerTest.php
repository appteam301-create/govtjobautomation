<?php
namespace Tests\Unit;
use App\Services\Crawling\ContentNormalizer;
use PHPUnit\Framework\TestCase;
class ContentNormalizerTest extends TestCase { public function test_it_removes_tracking_parameters():void{$n=new ContentNormalizer();$this->assertSame('https://example.gov.in/jobs?a=1',$n->url('https://EXAMPLE.gov.in/jobs?utm_source=x&a=1'));} }
