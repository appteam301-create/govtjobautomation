<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class JobUpdate extends Model { protected $guarded=[]; protected function casts():array{return ['changes'=>'array','reviewed_at'=>'datetime'];} }
