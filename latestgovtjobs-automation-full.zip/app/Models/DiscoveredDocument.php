<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class DiscoveredDocument extends Model { protected $guarded=[]; protected function casts():array{return ['metadata'=>'array','discovered_at'=>'datetime','processed_at'=>'datetime'];} public function source():BelongsTo{return $this->belongsTo(GovernmentSource::class,'government_source_id');} }
