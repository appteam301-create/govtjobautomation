<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SourceRule extends Model { protected $guarded=[]; protected function casts():array{return ['include_keywords'=>'array','ignore_keywords'=>'array','selectors'=>'array','patterns'=>'array','pagination'=>'array','enabled'=>'boolean'];} }
