<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class HumanReview extends Model { protected $guarded=[]; protected function casts():array{return ['before_data'=>'array','after_data'=>'array','reviewed_at'=>'datetime'];} }
