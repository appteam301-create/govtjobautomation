<?php
namespace App\Models;
use App\Enums\CandidateStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class JobCandidate extends Model { protected $guarded=[]; protected function casts():array{return ['status'=>CandidateStatus::class,'posts'=>'array','application_start_date'=>'date','application_last_date'=>'date','extracted_data'=>'array','confidence_score'=>'integer'];} public function evidence():HasMany{return $this->hasMany(JobEvidence::class);} public function reviews():HasMany{return $this->hasMany(HumanReview::class);} }
