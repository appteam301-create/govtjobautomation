<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AiUsage extends Model { protected $guarded=[]; protected function casts():array{return ['cost'=>'decimal:6','request_meta'=>'array','response_meta'=>'array'];} }
