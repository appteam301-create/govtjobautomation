<?php
namespace App\Models;
use App\Enums\CrawlerMode;
use App\Enums\SourceStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class GovernmentSource extends Model {
 protected $guarded=[];
 protected function casts():array{return ['crawler_mode'=>CrawlerMode::class,'status'=>SourceStatus::class,'last_crawled_at'=>'datetime','next_crawl_at'=>'datetime','settings'=>'array'];}
 public function rules():HasMany{return $this->hasMany(SourceRule::class);}
 public function crawlRuns():HasMany{return $this->hasMany(CrawlRun::class);}
 public function documents():HasMany{return $this->hasMany(DiscoveredDocument::class);}
}
