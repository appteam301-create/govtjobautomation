<?php
namespace App\Services\Pipeline;
use App\Enums\CandidateStatus;
use App\Models\DiscoveredDocument;
use App\Models\JobCandidate;
use App\Services\Ai\AiBudgetGuard;
use App\Services\Ai\AiFallbackService;
use App\Services\Extraction\ConfidenceScorer;
use App\Services\Extraction\DuplicateDetector;
use App\Services\Extraction\FieldExtractor;
use App\Services\Extraction\RecruitmentClassifier;
class CandidatePipeline {
 public function __construct(private RecruitmentClassifier $classifier,private FieldExtractor $extractor,private ConfidenceScorer $scorer,private DuplicateDetector $duplicates,private AiBudgetGuard $budget,private AiFallbackService $ai){}
 public function process(DiscoveredDocument $doc):?JobCandidate {
  $source=$doc->source; $classification=$this->classifier->classify($doc->title??'',$doc->raw_text??'',$source); if(!$classification['is_recruitment']){$doc->update(['processed_at'=>now()]);return null;}
  $data=$this->extractor->extract($doc->title??'',$doc->raw_text??'',$doc->url);$data['organization']=$source->organization;$data['department']=$source->department;$data['state']=$source->state;$data['government_level']=$source->government_level;if($doc->document_type==='pdf')$data['notification_pdf_url']=$doc->url;
  $score=$this->scorer->score($data,true,true); if($score<60 && $this->budget->canCall()){if($proposal=$this->ai->propose(['source'=>$source->only(['name','organization','state']),'document'=>$doc->only(['url','title','raw_text']),'deterministic'=>$data]))$data=array_replace($data,$proposal);$score=$this->scorer->score($data,true,true);}
  $key=$this->duplicates->key($data);$status=$this->duplicates->exists($key)?CandidateStatus::Duplicate:CandidateStatus::NeedsReview;if(!empty($data['application_last_date']) && $data['application_last_date']<today()->toDateString())$status=CandidateStatus::Expired;
  $candidate=JobCandidate::create(array_merge($data,['government_source_id'=>$source->id,'discovered_document_id'=>$doc->id,'status'=>$status,'confidence_score'=>$score,'dedupe_key'=>$key,'extracted_data'=>$data]));$doc->update(['processed_at'=>now()]);return $candidate;
 }
}
