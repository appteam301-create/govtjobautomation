<?php
namespace App\Services\Ai;
class NullAiFallbackService implements AiFallbackService { public function propose(array $context):?array{return null;} }
