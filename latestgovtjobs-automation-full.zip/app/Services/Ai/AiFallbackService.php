<?php
namespace App\Services\Ai;
interface AiFallbackService { public function propose(array $context):?array; }
