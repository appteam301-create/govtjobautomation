<?php
namespace App\Services\Ai;
use App\Models\AiUsage;
class AiBudgetGuard {
 public function canCall():bool {if(!config('govjobs.ai.enabled'))return false;$today=AiUsage::whereDate('created_at',today())->get();if($today->count()>=config('govjobs.ai.max_calls_per_day'))return false;if((float)$today->sum('cost')>=config('govjobs.ai.daily_budget'))return false;$month=(float)AiUsage::whereBetween('created_at',[now()->startOfMonth(),now()->endOfMonth()])->sum('cost');return $month<config('govjobs.ai.monthly_budget');}
}
