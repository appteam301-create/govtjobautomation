<?php
namespace App\Services\Publishing;
use App\Models\JobCandidate;
interface Publisher { public function publish(JobCandidate $candidate):array; }
