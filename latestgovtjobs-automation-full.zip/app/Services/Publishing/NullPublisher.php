<?php
namespace App\Services\Publishing;
use App\Models\JobCandidate;
class NullPublisher implements Publisher { public function publish(JobCandidate $candidate):array{return ['published'=>false,'reason'=>'No publishing driver configured'];} }
