<?php
namespace App\Services\Crawling;
use App\Models\GovernmentSource;
use App\Models\SourceSnapshot;
class ChangeDetector {
 public function isNew(GovernmentSource $source,string $fingerprint,array $payload=[]):bool {
  if(SourceSnapshot::where('government_source_id',$source->id)->where('fingerprint',$fingerprint)->exists()) return false;
  SourceSnapshot::create(['government_source_id'=>$source->id,'fingerprint'=>$fingerprint,'payload'=>$payload]); return true;
 }
}
