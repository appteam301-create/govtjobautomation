<?php
namespace App\Services\Crawling;
final class FetchResult { public function __construct(public readonly string $url, public readonly int $status, public readonly string $contentType, public readonly string $body, public readonly array $headers=[]){ } }
