<?php
namespace App\Services\Crawling;
use App\Enums\CrawlerMode;
use App\Models\DiscoveredDocument;
class DocumentContentResolver {
 public function __construct(private HttpFetcher $http,private ContentNormalizer $normalizer,private PdfTextExtractor $pdf,private BrowserRenderer $browser){}
 public function resolve(DiscoveredDocument $doc):array {
  $result=$this->http->fetch($doc->url);$type=$doc->document_type;
  if($type==='pdf'||str_contains($result->contentType,'application/pdf')){$x=$this->pdf->extract($result->body);return ['text'=>$x['text'],'metadata'=>['content_type'=>$result->contentType,'used_ocr'=>$x['used_ocr']]];}
  $html=$result->body;$text=$this->normalizer->text($html);$mode=$doc->source->crawler_mode;
  if(mb_strlen($text)<250 && in_array($mode,[CrawlerMode::Auto,CrawlerMode::Js],true)){try{$html=$this->browser->render($doc->url);$text=$this->normalizer->text($html);$rendered=true;}catch(\Throwable){$rendered=false;}}else{$rendered=false;}
  return ['text'=>$text,'metadata'=>['content_type'=>$result->contentType,'browser_rendered'=>$rendered]];
 }
}
