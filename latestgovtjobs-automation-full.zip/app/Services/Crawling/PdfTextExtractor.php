<?php
namespace App\Services\Crawling;
use Illuminate\Support\Facades\Process;
use RuntimeException;
class PdfTextExtractor {
 public function extract(string $pdfBytes):array {
  if(strlen($pdfBytes)>config('govjobs.crawler.max_pdf_bytes')) throw new RuntimeException('PDF exceeds size limit.');
  $dir=storage_path('app/tmp/govjobs/'.bin2hex(random_bytes(8)));@mkdir($dir,0700,true);$pdf="$dir/input.pdf";file_put_contents($pdf,$pdfBytes);
  try{$text=$this->pdftotext($pdf);$usedOcr=false;if(mb_strlen(trim($text))<150){$text=$this->ocr($pdf,$dir);$usedOcr=true;}return ['text'=>trim($text),'used_ocr'=>$usedOcr];}finally{$this->cleanup($dir);}
 }
 private function pdftotext(string $pdf):string {$out=$pdf.'.txt';$r=Process::timeout(45)->run([config('govjobs.crawler.pdftotext_binary'),'-layout',$pdf,$out]);if(!$r->successful()||!is_file($out))return '';return (string)file_get_contents($out);}
 private function ocr(string $pdf,string $dir):string {
  $prefix="$dir/page";$max=config('govjobs.crawler.ocr_max_pages');$r=Process::timeout(90)->run([config('govjobs.crawler.pdftoppm_binary'),'-f','1','-l',(string)$max,'-jpeg','-r','180',$pdf,$prefix]);if(!$r->successful()) return '';
  $all='';foreach(glob($prefix.'-*.jpg')?:[] as $img){$o=Process::timeout(45)->run([config('govjobs.crawler.tesseract_binary'),$img,'stdout','-l','eng']);if($o->successful())$all.="\n".$o->output();}return $all;
 }
 private function cleanup(string $dir):void {foreach(glob($dir.'/*')?:[] as $f)@unlink($f);@rmdir($dir);}
}
