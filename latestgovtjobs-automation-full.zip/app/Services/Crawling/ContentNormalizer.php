<?php
namespace App\Services\Crawling;
class ContentNormalizer {
 public function url(string $url):string {$p=parse_url($url); if(!$p)return $url; $scheme=strtolower($p['scheme']??'https');$host=strtolower($p['host']??'');$path=preg_replace('#/+#','/',$p['path']??'/');parse_str($p['query']??'',$q);foreach(array_keys($q) as $k){if(str_starts_with(strtolower($k),'utm_')||in_array(strtolower($k),['fbclid','gclid'],true))unset($q[$k]);}ksort($q);return $scheme.'://'.$host.$path.($q?'?'.http_build_query($q):'');}
 public function text(string $text):string {return trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($text),ENT_QUOTES|ENT_HTML5,'UTF-8')));}
 public function hash(string $value):string{return hash('sha256',$value);}
}
