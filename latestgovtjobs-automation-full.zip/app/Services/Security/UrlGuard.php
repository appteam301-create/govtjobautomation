<?php
namespace App\Services\Security;
use InvalidArgumentException;
class UrlGuard {
 public function assertSafe(string $url):void {
  $p=parse_url($url); if(!$p || empty($p['host']) || empty($p['scheme'])) throw new InvalidArgumentException('Invalid URL.');
  $scheme=strtolower($p['scheme']); if(!in_array($scheme,['https','http'],true)) throw new InvalidArgumentException('Unsupported URL scheme.');
  if($scheme==='http' && !config('govjobs.crawler.allow_http')) throw new InvalidArgumentException('HTTP URLs are disabled.');
  $host=strtolower(rtrim($p['host'],'.')); if($host==='localhost' || str_ends_with($host,'.local')) throw new InvalidArgumentException('Local hosts are blocked.');
  $ips=@gethostbynamel($host) ?: []; if(filter_var($host,FILTER_VALIDATE_IP)) $ips=[$host]; if(!$ips) throw new InvalidArgumentException('Host does not resolve.');
  foreach($ips as $ip){if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) throw new InvalidArgumentException('Private/reserved IP blocked.'); if($ip==='169.254.169.254') throw new InvalidArgumentException('Metadata IP blocked.');}
 }
}
