<?php
namespace App\Services\Extraction;
use Carbon\Carbon;
class FieldExtractor {
 public function extract(string $title,string $text,string $sourceUrl):array {
  $data=['job_title'=>$this->cleanTitle($title),'official_source_url'=>$sourceUrl];
  if(preg_match('/(?:advertisement|advt\.?|notification)\s*(?:no\.?|number)?\s*[:\-]?\s*([A-Z0-9\/\-\.]{2,40})/i',$text,$m))$data['advertisement_number']=trim($m[1]);
  if(preg_match('/(?:total\s+)?(?:vacancies|vacancy|posts?)\s*[:\-]?\s*(\d{1,6})/i',$text,$m))$data['total_vacancies']=(int)$m[1];
  $data['application_last_date']=$this->extractDate($text,['last date','closing date','apply before','last date for application']);
  $data['application_start_date']=$this->extractDate($text,['start date','opening date','application begins']);
  if(preg_match('#https?://[^\s"\'<>]+#i',$text,$m))$data['application_url']=$m[0];
  return array_filter($data,fn($v)=>$v!==null&&$v!=='');
 }
 private function cleanTitle(string $title):string {return trim(preg_replace('/\s+/u',' ',$title)) ?: 'Recruitment Notification';}
 private function extractDate(string $text,array $labels):?string {foreach($labels as $label){$re='/'.preg_quote($label,'/').'[^0-9]{0,35}(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4})/i';if(preg_match($re,$text,$m)){try{return Carbon::parse(str_replace(['/','.'],['-','-'],$m[1]))->toDateString();}catch(\Throwable){}}}return null;}
}
