<?php
namespace App\Services\Extraction;
class ConfidenceScorer {
 public function score(array $data,bool $knownSource=true,bool $recruitmentKeyword=true):int {
  $s=0;if($knownSource)$s+=25;if($recruitmentKeyword)$s+=15;if(!empty($data['advertisement_number']))$s+=10;if(!empty($data['notification_pdf_url']))$s+=15;if(!empty($data['application_url']))$s+=15;if(!empty($data['application_last_date']))$s+=10;if(!empty($data['total_vacancies']))$s+=5;if(!empty($data['qualification']))$s+=5;return min(100,$s);
 }
}
