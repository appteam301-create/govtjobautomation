<?php
namespace App\Services\Extraction;
use App\Models\GovernmentSource;
class RecruitmentClassifier {
 private array $positive=['recruitment','vacancy','vacancies','applications invited','apply online','direct recruitment','recruitment examination','walk-in','walk in','apprentice'];
 private array $negative=['final result','result','admit card','hall ticket','answer key','merit list','interview result','tender','procurement','promotion','transfer'];
 public function classify(string $title,string $text,GovernmentSource $source):array {
  $hay=mb_strtolower($title.' '.$text); $rule=$source->rules()->where('enabled',true)->first(); $positive=array_merge($this->positive,$rule?->include_keywords??[]); $negative=array_merge($this->negative,$rule?->ignore_keywords??[]);
  $neg=[];foreach($negative as $k)if($k!==''&&str_contains($hay,mb_strtolower($k)))$neg[]=$k; if($neg)return ['is_recruitment'=>false,'score'=>0,'reasons'=>['negative: '.implode(', ',$neg)]];
  $hits=[];foreach($positive as $k)if($k!==''&&str_contains($hay,mb_strtolower($k)))$hits[]=$k; return ['is_recruitment'=>count($hits)>0,'score'=>min(40,count($hits)*10),'reasons'=>$hits];
 }
}
