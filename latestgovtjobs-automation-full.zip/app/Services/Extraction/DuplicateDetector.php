<?php
namespace App\Services\Extraction;
use App\Models\JobCandidate;
class DuplicateDetector {
 public function key(array $data):string {return hash('sha256',mb_strtolower(trim(($data['organization']??'').'|'.($data['advertisement_number']??'').'|'.($data['job_title']??'').'|'.($data['notification_pdf_url']??'').'|'.($data['application_last_date']??''))));}
 public function exists(string $key):bool{return JobCandidate::where('dedupe_key',$key)->whereNotIn('status',['rejected','expired'])->exists();}
}
