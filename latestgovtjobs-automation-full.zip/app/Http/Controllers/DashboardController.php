<?php
namespace App\Http\Controllers;
use App\Models\CrawlerHealth;
use App\Models\GovernmentSource;
use App\Models\JobCandidate;
class DashboardController extends Controller {
 public function __invoke(){return view('dashboard',['active'=>GovernmentSource::where('status','active')->count(),'healthy'=>CrawlerHealth::where('status','healthy')->count(),'failed'=>CrawlerHealth::whereIn('status',['failed','blocked'])->count(),'review'=>JobCandidate::where('status','needs_review')->count(),'approved'=>JobCandidate::where('status','approved')->count()]);}
}
