<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminBasicAuth
{
    public function handle(Request $request, Closure $next): Response
    {
        $expectedUser = (string) env('ADMIN_USER', 'admin');
        $expectedPassword = (string) env('ADMIN_PASSWORD', '');

        if ($expectedPassword === '' || !hash_equals($expectedUser, (string) $request->getUser()) || !hash_equals($expectedPassword, (string) $request->getPassword())) {
            return response('Authentication required', 401, ['WWW-Authenticate' => 'Basic realm="LatestGovtJobs Automation"']);
        }

        return $next($request);
    }
}
