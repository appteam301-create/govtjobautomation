<?php
namespace App\Console\Commands;
use App\Enums\SourceStatus;
use App\Jobs\CrawlGovernmentSource;
use App\Models\GovernmentSource;
use Illuminate\Console\Command;
class CrawlDueSources extends Command { protected $signature='govjobs:crawl-due {--limit=100}'; protected $description='Queue active government sources that are due for crawling'; public function handle():int{$sources=GovernmentSource::where('status',SourceStatus::Active->value)->where(fn($q)=>$q->whereNull('next_crawl_at')->orWhere('next_crawl_at','<=',now()))->limit((int)$this->option('limit'))->get();foreach($sources as $s)CrawlGovernmentSource::dispatch($s->id);$this->info("Queued {$sources->count()} source(s).");return self::SUCCESS;} }
