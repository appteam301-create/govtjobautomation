<?php
namespace App\Enums;
enum CrawlerMode:string { case Auto='AUTO'; case Html='HTML'; case Js='JS'; case Pdf='PDF'; case Api='API'; case Rss='RSS'; case Sitemap='SITEMAP'; case Custom='CUSTOM'; }
