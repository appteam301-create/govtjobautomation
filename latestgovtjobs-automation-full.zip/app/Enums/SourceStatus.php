<?php
namespace App\Enums;
enum SourceStatus:string { case Active='active'; case Paused='paused'; }
