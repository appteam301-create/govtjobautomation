<?php
namespace App\Enums;
enum CandidateStatus:string { case NeedsReview='needs_review'; case Approved='approved'; case Rejected='rejected'; case Published='published'; case Duplicate='duplicate'; case Expired='expired'; }
