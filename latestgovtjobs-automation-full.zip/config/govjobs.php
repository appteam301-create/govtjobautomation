<?php
return [
    'crawler' => [
        'user_agent' => env('CRAWLER_USER_AGENT', 'LatestGovtJobsBot/1.0'),
        'timeout' => (int) env('CRAWLER_TIMEOUT', 20),
        'max_bytes' => (int) env('CRAWLER_MAX_BYTES', 15 * 1024 * 1024),
        'max_pdf_bytes' => (int) env('CRAWLER_MAX_PDF_BYTES', 25 * 1024 * 1024),
        'allow_http' => (bool) env('CRAWLER_ALLOW_HTTP', false),
        'chrome_binary' => env('CHROME_BINARY', '/usr/bin/google-chrome'),
        'pdftotext_binary' => env('PDFTOTEXT_BINARY', '/usr/bin/pdftotext'),
        'pdftoppm_binary' => env('PDFTOPPM_BINARY', '/usr/bin/pdftoppm'),
        'tesseract_binary' => env('TESSERACT_BINARY', '/usr/bin/tesseract'),
        'ocr_max_pages' => (int) env('OCR_MAX_PAGES', 8),
    ],
    'ai' => [
        'enabled' => (bool) env('AI_ENABLED', false),
        'endpoint' => env('AI_ENDPOINT'),
        'api_key' => env('AI_API_KEY'),
        'model' => env('AI_MODEL'),
        'daily_budget' => (float) env('DAILY_AI_BUDGET', 1.00),
        'monthly_budget' => (float) env('MONTHLY_AI_BUDGET', 20.00),
        'max_calls_per_day' => (int) env('MAX_AI_CALLS_PER_DAY', 50),
    ],
    'publish' => [
        'driver' => env('PUBLISH_DRIVER', 'null'),
        'api_url' => env('PUBLISH_API_URL'),
        'api_token' => env('PUBLISH_API_TOKEN'),
    ],
];
