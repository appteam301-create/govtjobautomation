# Implementation status

## Implemented in this build
- Laravel domain schema for all 12 planned modules
- Source CRUD foundation
- Queue + scheduler entrypoint
- HTTP crawler foundation
- URL/SSRF guard
- HTML discovery
- Baseline/change fingerprinting
- Code-first recruitment classification
- Initial deterministic field extraction
- Duplicate/expiry rules
- Confidence score
- AI usage budget gate and fallback contract
- Draft candidate workflow
- Human review UI/history
- Health and crawl-run logging

## Scaffolded but intentionally not activated
- AI provider (disabled and null by default)
- Publisher to LatestGovtJobs (null by default)
- Job update/corrigendum table
- Evidence table

## Next implementation work
- PDF/OCR worker
- JS browser fallback
- advanced selectors/pagination
- source adapters
- evidence capture
- corrigendum matcher
- production publisher
- browser isolation/rate limiting improvements
- integration tests against real government sites
