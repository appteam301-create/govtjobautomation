# LatestGovtJobs Automation — Laravel 13

This repository is the first development build for the approved LatestGovtJobs.co.in automation plan. It is deliberately **code-first, AI-last, human-approved**.

## Included now

- Government source registry and source rules
- Scheduled queueing of due sources
- SSRF-aware HTTP fetching with response limits
- HTML link discovery and normalization
- Baseline/change detection using SHA-256 fingerprints
- Recruitment vs non-recruitment deterministic classification
- Initial field extraction (advertisement number, vacancies, application dates, URLs)
- Duplicate key detection and expiry filtering
- Code-based confidence scoring
- AI budget guard plus disabled-by-default fallback interface
- Draft job candidates
- Human approve/reject UI and correction history
- Crawler health tracking and crawl-run logs
- Tables for evidence, AI usage, corrigenda/job updates
- Publishing interface intentionally disabled until LatestGovtJobs integration is configured

## Important current boundary

This build implements the end-to-end HTML discovery path. JavaScript rendering, PDF text extraction/OCR, source-specific adapters, evidence page extraction, and the production LatestGovtJobs publisher are extension points for the next development increment. They are not falsely marked complete.

## Install into a fresh Laravel 13 application

1. Create/install a normal Laravel 13 project on a server with PHP 8.3+ and Composer.
2. Copy this repository's `app/`, `config/`, `database/`, `resources/`, `routes/`, and `tests/` into the Laravel project.
3. Merge the package requirements from this `composer.json` if using an existing Laravel installation.
4. Copy `.env.example` values into `.env` and configure MySQL + Redis.
5. Run:

```bash
composer install
php artisan key:generate
php artisan migrate
php artisan horizon
php artisan schedule:work
```

6. Add Laravel authentication (Breeze, Fortify, or your existing admin auth) because all automation admin routes are protected by `auth` middleware.
7. Keep `AI_ENABLED=false` until deterministic accuracy has been measured on real sources.

## Queue design

- Scheduler runs `govjobs:crawl-due` every five minutes.
- The command only queues sources whose `next_crawl_at` is due.
- `CrawlGovernmentSource` fetches the recruitment page and detects new links.
- Only new fingerprints create `DiscoveredDocument` records.
- New documents are queued to `ProcessDiscoveredDocument`.
- Deterministic pipeline classifies, extracts, deduplicates, checks expiry, scores confidence and creates a draft.

## Human review guarantee

No crawler path can publish a candidate. New candidates use `needs_review`; approval only changes them to `approved`. The production publisher is a separate interface and is currently a null implementation. This separation is intentional.

## Security notes

`UrlGuard` blocks localhost, private/reserved IPv4 ranges and cloud metadata IP. HTTP is disabled by default. Production should additionally enforce outbound firewall rules, DNS re-resolution checks at the network layer, per-domain rate limiting, content-type allowlists, and isolated browser workers before enabling JS rendering.

## Next increment

Recommended sequence:

1. PDF downloader + `pdftotext` path and Tesseract OCR fallback.
2. Browser/JS worker interface (prefer isolated Node/Chrome service).
3. SourceRule-driven CSS selectors and pagination.
4. Source-specific adapters for UPSC/SSC/GPSC/GSSSB first.
5. Stronger date/qualification/salary/fee/post-table extraction.
6. Field-level evidence with PDF page numbers/snippets.
7. Corrigendum/deadline-extension matching.
8. Source-health dashboard.
9. LatestGovtJobs production publishing adapter/API mapping.
10. Optional low-cost AI implementation after real-source metrics prove where it is needed.
